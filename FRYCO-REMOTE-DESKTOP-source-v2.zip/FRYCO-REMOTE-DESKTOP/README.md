# FRYCO REMOTE DESKTOP — Android project scaffold

Status: **UI starter / belum menjadi klien RDP yang berfungsi**.

Project ini berisi dashboard Black Neon, form koneksi, pemilih mode Normal/Game/Coding,
serta preview layout tombol. Tombol Connect dan REC saat ini hanya memberi status,
bukan membuka sesi RDP atau merekam video. Jangan menganggap APK ini sebagai produk
remote desktop siap pakai.

## Build
1. Install Android Studio versi stabil di Windows.
2. Buka folder `FRYCO-REMOTE-DESKTOP`.
3. Install Android SDK Platform 35 dan JDK 17 jika diminta.
4. Tunggu Gradle Sync.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Integrasi RDP sungguhan (wajib sebelum rilis)
Gunakan source Android resmi FreeRDP:
https://github.com/FreeRDP/FreeRDP/tree/master/client/Android

Dokumen build:
https://github.com/FreeRDP/FreeRDP/blob/master/docs/README.android

FreeRDP Android terdiri dari Java UI, library native, dan JNI. Integrasi bukan
sekadar menambahkan dependency Maven. Porting perlu menyatukan lifecycle sesi,
surface/video rendering, input pointer/keyboard, autentikasi, sertifikat TLS,
dan callback status. Pertahankan lisensi dan pemberitahuan lisensi upstream.

## Fitur yang belum aktif
- Koneksi RDP native dan rendering desktop.
- Penyimpanan profil PC yang terenkripsi.
- Pengiriman input virtual gamepad dan gamepad Bluetooth/USB.
- Custom keyboard yang benar-benar mengirim scan code RDP.
- Screen recording MP4 via MediaProjection + foreground service.
- Daftar file rekaman dan penghapusan.

## Catatan host Windows
Remote Desktop bawaan Windows sebagai host memerlukan edisi Pro, Enterprise,
atau Education. Windows Home tidak menerima koneksi RDP masuk dengan fitur
bawaan Microsoft. Periksa Settings > System > About > Windows specifications > Edition.

Jangan membuka port RDP langsung ke internet. Untuk akses luar jaringan, gunakan
VPN tepercaya atau jaringan privat yang dikonfigurasi dengan benar. Jangan simpan
password sebagai teks biasa; gunakan Android Keystore-backed encryption.

## Pengujian yang diperlukan
1. Build dan install pada perangkat Android fisik.
2. Uji LAN ke host Windows yang memang mengaktifkan Remote Desktop.
3. Uji sertifikat, autentikasi, reconnect, dan disconnect.
4. Uji mouse, keyboard, gamepad fisik, dan virtual secara terpisah.
5. Uji perekaman, izin, penyimpanan MP4, dan penghentian service.


## Digital System startup sound
An original synthesized startup chime is included at
`app/src/main/res/raw/fryco_digital_system.wav`. It plays when the user presses
CONNECT with the required host and username fields filled. Default volume is
50%; the startup sound toggle is enabled by default. The sound is played locally
on the Android phone. It is not streamed to the remote Windows PC.

The Connect action remains a UI placeholder until the FreeRDP engine is integrated;
playing the sound does not mean an RDP session has connected.
