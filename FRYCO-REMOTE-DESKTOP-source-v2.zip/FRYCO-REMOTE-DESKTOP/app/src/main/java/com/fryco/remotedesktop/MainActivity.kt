package com.fryco.remotedesktop

import android.os.Bundle
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val Bg = Color(0xFF07090E)
private val Panel = Color(0xFF111722)
private val Neon = Color(0xFF16C8FF)
private val Muted = Color(0xFF91A2B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrycoApp() }
    }
}

@Composable
fun FrycoApp() {
    val context = LocalContext.current
    val soundPrefs = remember { context.getSharedPreferences("fryco_sound_settings", android.content.Context.MODE_PRIVATE) }
    var startupSoundEnabled by remember { mutableStateOf(soundPrefs.getBoolean("startup", true)) }
    var connectionSoundEnabled by remember { mutableStateOf(soundPrefs.getBoolean("connection", true)) }
    var disconnectSoundEnabled by remember { mutableStateOf(soundPrefs.getBoolean("disconnect", true)) }
    var muteAllSounds by remember { mutableStateOf(soundPrefs.getBoolean("mute_all", false)) }
    var startupVolume by remember { mutableFloatStateOf(soundPrefs.getFloat("volume", 0.50f)) }

    fun playFrycoStartupSound() {
        if (!startupSoundEnabled || muteAllSounds) return
        val player = MediaPlayer.create(context, R.raw.fryco_digital_system) ?: return
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        player.setVolume(startupVolume, startupVolume)
        player.setOnCompletionListener { it.release() }
        player.setOnErrorListener { mp, _, _ ->
            mp.release()
            true
        }
        player.start()
    }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("3389") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("NORMAL") }
    var status by remember { mutableStateOf("BELUM TERHUBUNG") }
    var showKeyboard by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Neon,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg)
                .verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).background(Neon, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.DesktopWindows, null, tint = Bg)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("FRYCO", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("REMOTE DESKTOP", color = Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text("V1.0", color = Muted, fontSize = 11.sp)
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("REMOTE CONTROL CENTER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Connect to your PC.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Secure remote workspace • Black Neon UI", color = Muted, fontSize = 12.sp)
            }

            NeonCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("CONNECTION", color = Neon, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(status, color = if (status == "CONNECTED") Color(0xFF54E39A) else Muted, fontSize = 10.sp)
                }
                FrycoField("PC ADDRESS / IP", host, { host = it }, "192.168.1.10")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(0.8f)) {
                        FrycoField("PORT", port, { port = it.filter(Char::isDigit) }, "3389", KeyboardType.Number)
                    }
                    Column(Modifier.weight(1.2f)) {
                        FrycoField("USERNAME", username, { username = it }, "Windows username")
                    }
                }
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("PASSWORD") },
                    placeholder = { Text("Windows account password") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = fieldColors()
                )
                Button(
                    onClick = {
                        if (host.isBlank() || username.isBlank()) {
                            status = "DATA BELUM LENGKAP"
                        } else {
                            playFrycoStartupSound()
                            status = "STARTUP SOUND DIPUTAR • RDP ENGINE BELUM DIINTEGRASIKAN"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Link, null)
                    Spacer(Modifier.width(8.dp))
                    Text("CONNECT TO PC", fontWeight = FontWeight.Black)
                }
                Text("Port default RDP: 3389 • Gunakan hanya PC milik sendiri/yang diizinkan.",
                    color = Muted, fontSize = 10.sp)
            }

            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("CONTROL MODES", color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("NORMAL", "GAME", "CODING").forEach { item ->
                        FilterChip(
                            selected = mode == item,
                            onClick = { mode = item },
                            label = { Text(item, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Neon,
                                selectedLabelColor = Bg,
                                labelColor = Color.White
                            )
                        )
                    }
                }
                when (mode) {
                    "GAME" -> GamepadPreview()
                    "CODING" -> CodingKeys()
                    else -> NormalControls()
                }
            }

            NeonCard {
                Text("AUDIO & SOUND SETTINGS", color = Neon, fontWeight = FontWeight.Bold)
                Text("Atur suara FRYCO sesuai kenyamanan kamu.", color = Muted, fontSize = 11.sp)
                SoundSettingRow("Startup Sound", "Digital System sebelum masuk RDP", startupSoundEnabled) {
                    startupSoundEnabled = it; soundPrefs.edit().putBoolean("startup", it).apply()
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Startup Volume", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text("${(startupVolume * 100).toInt()}%", color = Neon, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = startupVolume, onValueChange = { startupVolume = it },
                        onValueChangeFinished = { soundPrefs.edit().putFloat("volume", startupVolume).apply() },
                        colors = SliderDefaults.colors(thumbColor = Neon, activeTrackColor = Neon))
                }
                SoundSettingRow("Connection Sound", "Suara saat berhasil terhubung", connectionSoundEnabled) {
                    connectionSoundEnabled = it; soundPrefs.edit().putBoolean("connection", it).apply()
                }
                SoundSettingRow("Disconnect Sound", "Suara saat koneksi terputus", disconnectSoundEnabled) {
                    disconnectSoundEnabled = it; soundPrefs.edit().putBoolean("disconnect", it).apply()
                }
                Divider(color = Color(0xFF263548))
                SoundSettingRow("Mute All Sounds", "Matikan semua efek suara FRYCO", muteAllSounds) {
                    muteAllSounds = it; soundPrefs.edit().putBoolean("mute_all", it).apply()
                }
                Text("Pengaturan tersimpan otomatis di HP. Suara koneksi dan disconnect disiapkan sebagai opsi; bunyinya aktif setelah event RDP diintegrasikan.",
                    color = Muted, fontSize = 10.sp)
                Divider(color = Color(0xFF263548))
                Text("SESSION TOOLS", color = Neon, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showKeyboard = !showKeyboard }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Keyboard, null); Spacer(Modifier.width(5.dp)); Text("KEYBOARD")
                    }
                    OutlinedButton(onClick = { status = "REKAM: IZIN ANDROID DIPERLUKAN" }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FiberManualRecord, null, tint = Color.Red); Spacer(Modifier.width(5.dp)); Text("REC")
                    }
                }
                if (showKeyboard) CodingKeys()
                Text("Perekam layar dan konektor RDP asli perlu tahap integrasi native berikutnya.",
                    color = Muted, fontSize = 11.sp)
            }

            Text("FRYCO REMOTE DESKTOP • BUILT FOR MOBILE", color = Muted,
                fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SoundSettingRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Bg, checkedTrackColor = Neon))
    }
}

@Composable
private fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().border(1.dp, Color(0xFF16445A), RoundedCornerShape(18.dp))
            .background(Panel, RoundedCornerShape(18.dp)).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable
private fun FrycoField(
    label: String, value: String, onValue: (String) -> Unit,
    hint: String, type: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, placeholder = { Text(hint) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        colors = fieldColors()
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Neon, unfocusedBorderColor = Color(0xFF344456),
    focusedLabelColor = Neon, unfocusedLabelColor = Muted,
    cursorColor = Neon, focusedTextColor = Color.White, unfocusedTextColor = Color.White
)

@Composable
private fun GamepadPreview() {
    NeonCard {
        Text("VIRTUAL GAMEPAD • PREVIEW", color = Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("▲", color = Neon, fontSize = 23.sp)
                Row { GameKey("◀"); Spacer(Modifier.width(5.dp)); GameKey("▶") }
                Text("▼", color = Neon, fontSize = 23.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row { GameKey("Y"); Spacer(Modifier.width(5.dp)); GameKey("X") }
                Row { GameKey("B"); Spacer(Modifier.width(5.dp)); GameKey("A") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("L1", "L2", "R1", "R2", "START", "SELECT").forEach { GameKey(it) }
        }
        Text("Preview only: input mapping activates after RDP engine integration.",
            color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun GameKey(label: String) {
    Box(Modifier.border(1.dp, Neon, RoundedCornerShape(10.dp))
        .background(Color(0xFF0A2635), RoundedCornerShape(10.dp))
        .padding(horizontal = 11.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun CodingKeys() {
    NeonCard {
        Text("CODING SHORTCUTS", color = Neon, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        listOf(
            listOf("ESC", "TAB", "CTRL", "ALT", "SHIFT"),
            listOf("F1", "F2", "F3", "F4", "F5", "F6"),
            listOf("F7", "F8", "F9", "F10", "F11", "F12"),
            listOf("HOME", "END", "PGUP", "PGDN", "INS", "DEL"),
            listOf("←", "↑", "↓", "→", "ENTER")
        ).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                row.forEach { key -> Box(Modifier.weight(1f)) { GameKey(key) } }
            }
        }
        Text("Tombol di atas adalah layout awal; pengiriman input memerlukan adapter RDP.",
            color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun NormalControls() {
    NeonCard {
        Text("NORMAL MODE", color = Neon, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text("Touch untuk pointer • Keyboard untuk mengetik • Long press untuk klik kanan (saat adapter RDP aktif).",
            color = Muted, fontSize = 12.sp)
    }
}
